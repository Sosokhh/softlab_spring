package ge.softgen.softlab.softlabspring.service;

import ge.softgen.softlab.softlabspring.model.Person;
import ge.softgen.softlab.softlabspring.repository.PersonRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;


@RequiredArgsConstructor
@Service
public class PersonServiceImpl implements PersonService{

        private final PersonRepository personRepository;

    public List<Person> getPeople() {
        return personRepository.findAll();
    }

    public Person add(Person person) {
      return personRepository.save(person);
    }

    public Person get(int id) {
        return personRepository.findById(id).orElseThrow();
    }
    public Person update(Person person) {
        get(person.getId());
        return personRepository.save(person);
    }

    public void delete(int id ) {
        personRepository.delete(get(id));
    }
}
