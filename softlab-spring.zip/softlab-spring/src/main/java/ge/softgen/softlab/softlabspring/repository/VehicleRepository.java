package ge.softgen.softlab.softlabspring.repository;

import ge.softgen.softlab.softlabspring.model.Vehicle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


public interface VehicleRepository extends JpaRepository<Vehicle, Integer> {

}
