package ge.softgen.softlab.softlabspring.model;

import com.fasterxml.jackson.annotation.JsonBackReference;
import lombok.*;
import org.hibernate.Hibernate;

import javax.persistence.*;
import java.util.Objects;

@ToString

@NoArgsConstructor
@Getter
@Setter
@Entity
@Table(name = "vehicles")
@SequenceGenerator(name = "vehicleIdGenerator", sequenceName = "vehicles_id_seq", allocationSize = 1)
public class Vehicle {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "vehicleIdGenerator")
    public Integer id;
    @Column(name = "number")
    public String number;

    @Column(name = "owner_id")
    public Integer owner_id;

    @ManyToOne
    @JsonBackReference
    @JoinColumn(name = "owner_id", updatable = false, insertable = false)
    public Person owner;



    @Column(name = "maker")
    public String maker;
    @Column(name = "model")
    public String model;
    @Column(name = "engyne_type")
    public Integer engyneType;
    @Column(name = "engine_volume")
    public Integer engineVolume;




    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || Hibernate.getClass(this) != Hibernate.getClass(o)) return false;
        Vehicle vehicle = (Vehicle) o;
        return id != null && Objects.equals(id, vehicle.id);
    }

    @Override
    public int hashCode() {
        return getClass().hashCode();
    }
}
