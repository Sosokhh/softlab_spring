package ge.softgen.softlab.softlabspring.controller;

import ge.softgen.softlab.softlabspring.model.Vehicle;
import ge.softgen.softlab.softlabspring.repository.VehicleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
public class VehicleController {
    private final VehicleRepository vehicleRepository;


    @GetMapping("/vehicles/{id}")
    public Vehicle getVehicle(@PathVariable int id) {
        return vehicleRepository.findById(id).orElseThrow();
    }
}
