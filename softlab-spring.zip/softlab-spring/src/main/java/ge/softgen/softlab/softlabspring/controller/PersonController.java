package ge.softgen.softlab.softlabspring.controller;

import ge.softgen.softlab.softlabspring.model.Person;
import ge.softgen.softlab.softlabspring.service.PersonService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/people")
public class PersonController {

    private final PersonService personService;


    @GetMapping
    public List<Person> getPeople() {
        return personService.getPeople();
    }


    @PostMapping
    public ResponseEntity<Person> addNewPerson(@RequestBody Person person) {
        return ResponseEntity.status(201).body(personService.add(person));
    }

    @PutMapping("{id}")
    public ResponseEntity<Person> updatePerson(@PathVariable int  id,
                                               @RequestBody Person person) {
        try {
           person.setId(id);
           Person dbPerson = personService.update(person);
            return ResponseEntity.ok(dbPerson);


        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }


    @DeleteMapping("{id}")
    public ResponseEntity<Void> deletePerson(@PathVariable int id) {
        try {
           personService.delete(id);
           return ResponseEntity.noContent().build();
        }


        catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
        }


    @GetMapping("{id}")
    public ResponseEntity<Person> getPerson(@PathVariable int id) {
        try {
            return ResponseEntity.ok(personService.get(id));


        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}
