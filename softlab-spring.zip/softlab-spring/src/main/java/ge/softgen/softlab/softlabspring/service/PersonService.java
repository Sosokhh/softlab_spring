package ge.softgen.softlab.softlabspring.service;

import ge.softgen.softlab.softlabspring.model.Person;

import java.util.List;

public interface PersonService {
     List<Person> getPeople();
     Person  add(Person person);
     Person get(int id);
     Person update(Person person);
     void delete(int id );
}
